# Tópicos de Linguagem de Programação 2 (2022.2 - 229A)
Repositório para guardar os códigos do professor.

___

# Como baixar

```
~$ git clone https://github.com/mira-oza/tlp2-2022.1.git
~$ cd tlp2-2022.1/
```

Uma alternativa é clicar no botão verde "Code" e clicar em "Download zip". :)
