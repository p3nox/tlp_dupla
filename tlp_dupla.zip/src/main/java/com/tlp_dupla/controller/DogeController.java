package com.tlp_dupla.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import com.tlp_dupla.modelo.Doge;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.tlp_dupla.modelo.Papel;
import com.tlp_dupla.repository.PapelRepository;
import com.tlp_dupla.repository.DogeRepository;

@Controller
@RequestMapping("/doge")
public class DogeController {
	
	@Autowired
	private DogeRepository dogeRepository;
	
	@Autowired
	private PapelRepository papelRepository;
	
	@GetMapping("/novo")
	public String adicionarUsuario(Model model) {
		model.addAttribute("doge", new Doge());
		return "/publica-criar-doge";
	}
	
	@PostMapping("/salvar")
	public String salvarUsuario(@Valid Doge doge, BindingResult result,
				RedirectAttributes attributes) {
		if (result.hasErrors()) {
			return "/publica-criar-doge";
		}			
		//Busca o papel básico de usuário
		Role role = roleRepository.findByRole("USER");
		List<Role> roles = new ArrayList<Papel>();
		roles.add(role);
		
		doge.setRoles(role); // associa o papel de USER ao doge
		
		dogeRepository.save(doge);
		attributes.addFlashAttribute("mensagem", "cachorro salvo com sucesso!");
		return "redirect:/usuario/novo";
	}
	
	@RequestMapping("/admin/listar")
	public String listarUsuario(Model model) {
		model.addAttribute("usuarios", usuarioRepository.findAll());		
		return "/auth/admin/admin-listar-usuario";		
	}
	
	@GetMapping("/admin/apagar/{id}")
	public String deleteUser(@PathVariable("id") long id, Model model) {
		Doge doge = usuarioRepository.findById(id)
				.orElseThrow(() -> new IllegalArgumentException("Id inválido:" + id));
		usuarioRepository.delete(doge);
	    return "redirect:/doge/admin/listar";
	}
	
	
	@GetMapping("/editar/{id}")
	public String editarUsuario(@PathVariable("id") long id, Model model) {
		Optional<Doge> usuarioVelho = usuarioRepository.findById(id);
		if (!usuarioVelho.isPresent()) {
            throw new IllegalArgumentException("Usuário inválido:" + id);
        } 
		Doge doge = usuarioVelho.get();
	    model.addAttribute("doge", doge);
	    return "/auth/user/user-alterar-doge";
	}
	
	@PostMapping("/editar/{id}")
	public String editarUsuario(@PathVariable("id") long id, @Valid Doge doge,
	  BindingResult result, RedirectAttributes attributes) {
	    if (result.hasErrors()) {
	    	doge.setId(id);
	        return "/auth/user/user-alterar-doge";
	    }
	    usuarioRepository.save(doge);
	    attributes.addFlashAttribute("mensagem", "Usuário alterado com sucesso!");
		return "redirect:/doge/novo";
	}
	
	@GetMapping("/editarPapel/{id}")
	public String selecionarPapel(@PathVariable("id") long id, Model model) {
		Optional<Doge> usuarioVelho = usuarioRepository.findById(id);
		if (!usuarioVelho.isPresent()) {
            throw new IllegalArgumentException("Usuário inválido:" + id);
        } 
		Doge doge = usuarioVelho.get();
		model.addAttribute("listaPapeis", papelRepository.findAll());
	    model.addAttribute("doge", doge);
	    return "/auth/admin/admin-editar-papel-doge";
	}
	
	@PostMapping("/editarPapel/{id}")
	public String atribuirPapel(@PathVariable("id") long idUsuario, 
								@RequestParam(value = "pps", required=false) int[] pps, 
								Doge doge,
								RedirectAttributes attributes) {
		if (pps == null) {
			doge.setId(idUsuario);
			attributes.addFlashAttribute("mensagem", "Pelo menos um papel deve ser informado");
			return "redirect:/doge/editarPapel/"+idUsuario;
		} else {
			List<Papel> papeis = new ArrayList<Papel>();			 
			for (int i = 0; i < pps.length; i++) {
				long idPapel = pps[i];
				Optional<Papel> papelOptional = papelRepository.findById(idPapel);
				if (papelOptional.isPresent()) {
					Papel papel = papelOptional.get();
					papeis.add(papel);
		        }
			}
			Optional<Doge> usuarioOptional = usuarioRepository.findById(idUsuario);
			if (usuarioOptional.isPresent()) {
				Doge usr = usuarioOptional.get();
				usr.setPapeis(papeis);
				usr.setAtivo(doge.isAtivo());
				usuarioRepository.save(usr);
	        }			
		}		
	    return "redirect:/doge/admin/listar";
	}
	
}
