package com.tlp_dupla;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class tlp_duplaApplication {

	public static void main(String[] args) {
		SpringApplication.run(tlp_duplaApplication.class, args);
	}

}