package com.tlp_dupla.component;

import com.tlp_dupla.repository.PapelRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.tlp_dupla.modelo.Papel;

@Component
public class DataLoader implements CommandLineRunner {
	
	@Autowired
	private PapelRepository papelRepository;
	
	@Override
	public void run(String... args) throws Exception {
		
		String[] roles = {"ADMIN", "USER"};
		
		for (String roleString: roles) {
			Papel role = papelRepository.findByPapel(roleString);
			if (role == null) {
				role = new Papel(roleString);
				papelRepository.save(role);
			}
		}				
	}
}
