package com.tlp_dupla.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tlp_dupla.modelo.Papel;

public interface PapelRepository extends JpaRepository<Papel, Long> {
	Papel findByPapel(String papel);
}
