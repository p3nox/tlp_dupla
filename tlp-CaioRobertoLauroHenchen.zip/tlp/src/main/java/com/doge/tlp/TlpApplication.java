package com.doge.tlp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TlpApplication {

	public static void main(String[] args) {
		SpringApplication.run(TlpApplication.class, args);
	}

}
