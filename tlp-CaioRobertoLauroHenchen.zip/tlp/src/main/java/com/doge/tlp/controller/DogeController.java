package com.doge.tlp.controller;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.ui.Model;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.doge.tlp.modelo.Doge;
import com.doge.tlp.repository.DogeRepository;

@Controller
public class DogeController {
	@Autowired
	private DogeRepository dogeRepository;
	
	@GetMapping("/adicionar-doge")
	public String adicionarDoge(Model model) {
		model.addAttribute("doge", new Doge());
		
		return "/criar-doge";
	}
	
	@PostMapping("/salvar")
	public String salvarDoge(@Valid Doge doge, BindingResult result,
				RedirectAttributes attributes) {
		if (result.hasErrors()) {
			return "/criar-doge";
		}			
		
		dogeRepository.save(doge);
		return "redirect:/listar-doges";
	}
	
	@GetMapping("/listar-doges")
	public String listarDoges(Model model) {
		model.addAttribute("doges", dogeRepository.findAll());		
		return "/listar-doges";		
	}
	
	@GetMapping("/apagar-doge/{id}")
	public String deleteDoge(@PathVariable("id") long id, Model model) {
		Doge doge = dogeRepository.findById(id)
				.orElseThrow(() -> new IllegalArgumentException("Id inválido:" + id));
		dogeRepository.delete(doge);
	    return "redirect:/listar-doges";
	}
	
	@GetMapping("/editar-doge/{id}")
	public String editarDoge(@PathVariable("id") long id, Model model) {
		Optional<Doge> dogeVelho = dogeRepository.findById(id);
		if (!dogeVelho.isPresent()) {
            throw new IllegalArgumentException("Id inválido:" + id);
        } 
		Doge doge = dogeVelho.get();
	    model.addAttribute("doge", doge);
	    return "/alterar-doge";
	}
	
	@PostMapping("/alterar/{id}")
	public String alterarDoge(@PathVariable("id") long id, @Valid Doge doge,
	  BindingResult result, RedirectAttributes attributes) {
	    if (result.hasErrors()) {
	    	doge.setId(id);
	        return "/alterar-doge";
	    }
	    dogeRepository.save(doge);
		return "redirect:/listar-doges";
	}
}