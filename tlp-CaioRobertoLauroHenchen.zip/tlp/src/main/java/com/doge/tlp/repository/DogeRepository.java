package com.doge.tlp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.doge.tlp.modelo.Doge;

public interface DogeRepository extends JpaRepository<Doge, Long> {
	
}
