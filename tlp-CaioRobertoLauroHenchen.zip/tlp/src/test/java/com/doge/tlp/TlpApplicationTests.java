package com.doge.tlp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TlpApplicationTests {

	@Test
	void contextLoads() {
	}

}
